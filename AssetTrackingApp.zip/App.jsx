import React, { useState, useEffect, useCallback } from 'react';

// ============================================================================
// RF & RFID ASSET TRACKING APPLICATION
// Integrated with NetSuite for Enterprise Asset Management
// ============================================================================

// Simulated NetSuite API Service
const NetSuiteAPI = {
  async authenticate(credentials) {
    // In production: OAuth 2.0 flow with NetSuite REST API
    await new Promise(r => setTimeout(r, 1200));
    if (credentials.email && credentials.password) {
      return {
        success: true,
        user: {
          id: 'USR-001',
          name: 'Alex Martinez',
          role: 'Asset Manager',
          subsidiary: 'Corporate HQ',
          token: 'ns_token_' + Date.now()
        }
      };
    }
    return { success: false, error: 'Invalid credentials' };
  },

  async syncAssets(token) {
    // In production: GET /record/v1/customrecord_asset with search filters
    await new Promise(r => setTimeout(r, 2000));
    return {
      success: true,
      lastSync: new Date().toISOString(),
      assets: generateMockAssets(),
      areas: [
        { id: 'AREA-001', name: 'Warehouse A - Zone 1', assetCount: 156 },
        { id: 'AREA-002', name: 'Warehouse A - Zone 2', assetCount: 89 },
        { id: 'AREA-003', name: 'Warehouse B - Main Floor', assetCount: 234 },
        { id: 'AREA-004', name: 'Office Building - Floor 1', assetCount: 67 },
        { id: 'AREA-005', name: 'Office Building - Floor 2', assetCount: 45 },
        { id: 'AREA-006', name: 'Data Center', assetCount: 312 },
        { id: 'AREA-007', name: 'Manufacturing Plant', assetCount: 189 }
      ]
    };
  },

  async updateAssets(token, updates) {
    // In production: PATCH /record/v1/customrecord_asset/{id}
    await new Promise(r => setTimeout(r, 1500));
    return { success: true, updated: updates.length };
  }
};

// Scanner Service - Handles RF and RFID hardware integration
const ScannerService = {
  connectedScanners: [],
  
  async discoverDevices() {
    // In production: Uses Web Bluetooth API, WebUSB, or native SDKs
    await new Promise(r => setTimeout(r, 1000));
    return [
      { id: 'ZBR-MC9300', name: 'Zebra MC9300', type: 'RF', status: 'available', battery: 87 },
      { id: 'HON-CT60', name: 'Honeywell CT60', type: 'RF', status: 'available', battery: 92 },
      { id: 'IMP-R700', name: 'Impinj R700', type: 'RFID', status: 'available', signalStrength: 'excellent' },
      { id: 'ZBR-FX9600', name: 'Zebra FX9600', type: 'RFID', status: 'available', signalStrength: 'good' }
    ];
  },

  async connect(deviceId) {
    await new Promise(r => setTimeout(r, 800));
    return { success: true, deviceId };
  },

  simulateScan(type, expectedAssets) {
    // Simulates scanning results
    const scanned = expectedAssets.slice(0, Math.floor(expectedAssets.length * 0.85));
    const missing = expectedAssets.slice(Math.floor(expectedAssets.length * 0.85));
    const unexpected = [
      { id: 'AST-NEW-001', tag: 'RF-789456', name: 'Unregistered Laptop', type: 'RF' },
      { id: 'AST-NEW-002', tag: 'RFID-456789', name: 'Unknown Equipment', type: 'RFID' }
    ];
    return { scanned, missing, unexpected };
  }
};

// Generate mock asset data
function generateMockAssets() {
  const categories = ['IT Equipment', 'Furniture', 'Machinery', 'Vehicles', 'Tools'];
  const statuses = ['Active', 'In Service', 'Maintenance', 'Retired'];
  const assets = [];
  
  for (let i = 1; i <= 500; i++) {
    const hasRFID = Math.random() > 0.3;
    assets.push({
      id: `AST-${String(i).padStart(5, '0')}`,
      name: `Asset ${i} - ${categories[i % categories.length]}`,
      category: categories[i % categories.length],
      rfTag: `RF-${String(100000 + i).padStart(6, '0')}`,
      rfidTag: hasRFID ? `RFID-${String(200000 + i).padStart(8, '0')}` : null,
      area: `AREA-00${(i % 7) + 1}`,
      status: statuses[i % statuses.length],
      lastScanned: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000).toISOString(),
      value: Math.floor(Math.random() * 50000) + 500
    });
  }
  return assets;
}

// ============================================================================
// MAIN APPLICATION COMPONENT
// ============================================================================

export default function AssetTrackingApp() {
  const [currentView, setCurrentView] = useState('login');
  const [user, setUser] = useState(null);
  const [assets, setAssets] = useState([]);
  const [areas, setAreas] = useState([]);
  const [schedules, setSchedules] = useState([]);
  const [scanners, setScanners] = useState([]);
  const [connectedScanner, setConnectedScanner] = useState(null);
  const [syncStatus, setSyncStatus] = useState({ lastSync: null, syncing: false });
  const [notifications, setNotifications] = useState([]);
  const [activeScanSession, setActiveScanSession] = useState(null);
  const [pendingApprovals, setPendingApprovals] = useState([]);

  // Add notification helper
  const addNotification = useCallback((type, message) => {
    const id = Date.now();
    setNotifications(prev => [...prev, { id, type, message }]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n.id !== id));
    }, 4000);
  }, []);

  // Handle login
  const handleLogin = async (credentials) => {
    const result = await NetSuiteAPI.authenticate(credentials);
    if (result.success) {
      setUser(result.user);
      setCurrentView('dashboard');
      addNotification('success', `Welcome back, ${result.user.name}!`);
    } else {
      addNotification('error', result.error);
    }
    return result;
  };

  // Sync with NetSuite
  const handleSync = async () => {
    setSyncStatus(prev => ({ ...prev, syncing: true }));
    try {
      const result = await NetSuiteAPI.syncAssets(user?.token);
      if (result.success) {
        setAssets(result.assets);
        setAreas(result.areas);
        setSyncStatus({ lastSync: result.lastSync, syncing: false });
        addNotification('success', `Synced ${result.assets.length} assets from NetSuite`);
      }
    } catch (error) {
      setSyncStatus(prev => ({ ...prev, syncing: false }));
      addNotification('error', 'Sync failed. Please try again.');
    }
  };

  // Discover scanners
  const discoverScanners = async () => {
    const devices = await ScannerService.discoverDevices();
    setScanners(devices);
    addNotification('info', `Found ${devices.length} scanner devices`);
  };

  // Connect to scanner
  const connectScanner = async (device) => {
    const result = await ScannerService.connect(device.id);
    if (result.success) {
      setConnectedScanner(device);
      addNotification('success', `Connected to ${device.name}`);
    }
  };

  // Create schedule
  const createSchedule = (scheduleData) => {
    const newSchedule = {
      id: `SCH-${Date.now()}`,
      ...scheduleData,
      status: 'Scheduled',
      createdAt: new Date().toISOString(),
      createdBy: user?.name
    };
    setSchedules(prev => [...prev, newSchedule]);
    addNotification('success', 'Asset count scheduled successfully');
    return newSchedule;
  };

  // Start scan session
  const startScanSession = (schedule) => {
    const areaAssets = assets.filter(a => schedule.areas.includes(a.area));
    setActiveScanSession({
      scheduleId: schedule.id,
      areas: schedule.areas,
      expectedAssets: areaAssets,
      scannedAssets: [],
      missingAssets: [],
      unexpectedAssets: [],
      startTime: new Date().toISOString(),
      status: 'in-progress'
    });
    setCurrentView('scanning');
  };

  // Process scan results
  const processScanResults = (results) => {
    setActiveScanSession(prev => ({
      ...prev,
      scannedAssets: results.scanned,
      missingAssets: results.missing,
      unexpectedAssets: results.unexpected,
      status: 'review'
    }));
  };

  // Submit for approval
  const submitForApproval = () => {
    const approval = {
      id: `APR-${Date.now()}`,
      sessionData: activeScanSession,
      submittedAt: new Date().toISOString(),
      submittedBy: user?.name,
      status: 'pending'
    };
    setPendingApprovals(prev => [...prev, approval]);
    setActiveScanSession(null);
    setCurrentView('approvals');
    addNotification('success', 'Scan results submitted for approval');
  };

  // Approve and sync to NetSuite
  const approveAndSync = async (approvalId) => {
    const approval = pendingApprovals.find(a => a.id === approvalId);
    if (approval) {
      const updates = approval.sessionData.scannedAssets.map(asset => ({
        id: asset.id,
        lastScanned: new Date().toISOString(),
        status: 'Verified'
      }));
      
      const result = await NetSuiteAPI.updateAssets(user?.token, updates);
      if (result.success) {
        setPendingApprovals(prev => prev.filter(a => a.id !== approvalId));
        addNotification('success', `${result.updated} asset records updated in NetSuite`);
      }
    }
  };

  // Render based on current view
  const renderView = () => {
    switch (currentView) {
      case 'login':
        return <LoginScreen onLogin={handleLogin} />;
      case 'dashboard':
        return (
          <Dashboard
            user={user}
            assets={assets}
            areas={areas}
            schedules={schedules}
            syncStatus={syncStatus}
            onSync={handleSync}
            onNavigate={setCurrentView}
            pendingApprovals={pendingApprovals}
          />
        );
      case 'sync':
        return (
          <SyncScreen
            syncStatus={syncStatus}
            onSync={handleSync}
            assets={assets}
            areas={areas}
            onBack={() => setCurrentView('dashboard')}
          />
        );
      case 'scheduling':
        return (
          <SchedulingScreen
            areas={areas}
            schedules={schedules}
            onCreateSchedule={createSchedule}
            onStartScan={startScanSession}
            onBack={() => setCurrentView('dashboard')}
          />
        );
      case 'scanners':
        return (
          <ScannerSetupScreen
            scanners={scanners}
            connectedScanner={connectedScanner}
            onDiscover={discoverScanners}
            onConnect={connectScanner}
            onBack={() => setCurrentView('dashboard')}
          />
        );
      case 'scanning':
        return (
          <ScanningScreen
            session={activeScanSession}
            scanner={connectedScanner}
            onProcessResults={processScanResults}
            onSubmit={submitForApproval}
            onBack={() => setCurrentView('scheduling')}
          />
        );
      case 'approvals':
        return (
          <ApprovalScreen
            approvals={pendingApprovals}
            onApprove={approveAndSync}
            onReject={(id) => setPendingApprovals(prev => prev.filter(a => a.id !== id))}
            onBack={() => setCurrentView('dashboard')}
          />
        );
      default:
        return <Dashboard onNavigate={setCurrentView} />;
    }
  };

  return (
    <div className="app-container">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Outfit:wght@300;400;500;600;700;800&display=swap');
        
        :root {
          --bg-primary: #0a0e14;
          --bg-secondary: #111820;
          --bg-tertiary: #1a2332;
          --bg-elevated: #212d40;
          --accent-primary: #00d9ff;
          --accent-secondary: #7c3aed;
          --accent-success: #10b981;
          --accent-warning: #f59e0b;
          --accent-error: #ef4444;
          --text-primary: #f1f5f9;
          --text-secondary: #94a3b8;
          --text-muted: #64748b;
          --border-color: #2a3a4d;
          --gradient-primary: linear-gradient(135deg, #00d9ff 0%, #7c3aed 100%);
          --gradient-glow: radial-gradient(ellipse at center, rgba(0, 217, 255, 0.15) 0%, transparent 70%);
          --shadow-glow: 0 0 40px rgba(0, 217, 255, 0.15);
        }
        
        * {
          margin: 0;
          padding: 0;
          box-sizing: border-box;
        }
        
        body {
          font-family: 'Outfit', sans-serif;
          background: var(--bg-primary);
          color: var(--text-primary);
          min-height: 100vh;
          overflow-x: hidden;
        }
        
        .app-container {
          min-height: 100vh;
          position: relative;
          background: 
            var(--gradient-glow),
            linear-gradient(180deg, var(--bg-primary) 0%, var(--bg-secondary) 100%);
        }
        
        /* Notification System */
        .notifications {
          position: fixed;
          top: 20px;
          right: 20px;
          z-index: 1000;
          display: flex;
          flex-direction: column;
          gap: 10px;
        }
        
        .notification {
          padding: 14px 20px;
          border-radius: 12px;
          background: var(--bg-elevated);
          border: 1px solid var(--border-color);
          display: flex;
          align-items: center;
          gap: 12px;
          animation: slideIn 0.3s ease;
          backdrop-filter: blur(10px);
          min-width: 300px;
        }
        
        .notification.success { border-left: 4px solid var(--accent-success); }
        .notification.error { border-left: 4px solid var(--accent-error); }
        .notification.warning { border-left: 4px solid var(--accent-warning); }
        .notification.info { border-left: 4px solid var(--accent-primary); }
        
        @keyframes slideIn {
          from { transform: translateX(100%); opacity: 0; }
          to { transform: translateX(0); opacity: 1; }
        }
        
        /* Login Screen */
        .login-container {
          min-height: 100vh;
          display: flex;
          align-items: center;
          justify-content: center;
          padding: 20px;
          position: relative;
        }
        
        .login-background {
          position: absolute;
          inset: 0;
          overflow: hidden;
        }
        
        .login-background::before {
          content: '';
          position: absolute;
          width: 600px;
          height: 600px;
          background: radial-gradient(circle, rgba(0, 217, 255, 0.1) 0%, transparent 70%);
          top: -200px;
          right: -200px;
          animation: pulse 8s ease-in-out infinite;
        }
        
        .login-background::after {
          content: '';
          position: absolute;
          width: 400px;
          height: 400px;
          background: radial-gradient(circle, rgba(124, 58, 237, 0.1) 0%, transparent 70%);
          bottom: -100px;
          left: -100px;
          animation: pulse 6s ease-in-out infinite reverse;
        }
        
        @keyframes pulse {
          0%, 100% { transform: scale(1); opacity: 0.5; }
          50% { transform: scale(1.2); opacity: 0.8; }
        }
        
        .login-card {
          background: var(--bg-secondary);
          border: 1px solid var(--border-color);
          border-radius: 24px;
          padding: 48px;
          width: 100%;
          max-width: 440px;
          position: relative;
          z-index: 1;
          box-shadow: var(--shadow-glow);
        }
        
        .login-logo {
          text-align: center;
          margin-bottom: 40px;
        }
        
        .login-logo-icon {
          width: 72px;
          height: 72px;
          background: var(--gradient-primary);
          border-radius: 18px;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 20px;
          font-size: 32px;
        }
        
        .login-logo h1 {
          font-size: 28px;
          font-weight: 700;
          background: var(--gradient-primary);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          margin-bottom: 8px;
        }
        
        .login-logo p {
          color: var(--text-secondary);
          font-size: 14px;
        }
        
        .form-group {
          margin-bottom: 24px;
        }
        
        .form-label {
          display: block;
          font-size: 13px;
          font-weight: 500;
          color: var(--text-secondary);
          margin-bottom: 8px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
        
        .form-input {
          width: 100%;
          padding: 14px 18px;
          background: var(--bg-tertiary);
          border: 1px solid var(--border-color);
          border-radius: 12px;
          color: var(--text-primary);
          font-size: 15px;
          font-family: inherit;
          transition: all 0.2s ease;
        }
        
        .form-input:focus {
          outline: none;
          border-color: var(--accent-primary);
          box-shadow: 0 0 0 3px rgba(0, 217, 255, 0.1);
        }
        
        .form-input::placeholder {
          color: var(--text-muted);
        }
        
        .btn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          gap: 10px;
          padding: 14px 28px;
          border-radius: 12px;
          font-size: 15px;
          font-weight: 600;
          font-family: inherit;
          cursor: pointer;
          transition: all 0.2s ease;
          border: none;
          text-decoration: none;
        }
        
        .btn-primary {
          background: var(--gradient-primary);
          color: var(--bg-primary);
          width: 100%;
        }
        
        .btn-primary:hover {
          transform: translateY(-2px);
          box-shadow: 0 10px 30px rgba(0, 217, 255, 0.3);
        }
        
        .btn-secondary {
          background: var(--bg-tertiary);
          color: var(--text-primary);
          border: 1px solid var(--border-color);
        }
        
        .btn-secondary:hover {
          background: var(--bg-elevated);
          border-color: var(--accent-primary);
        }
        
        .btn-ghost {
          background: transparent;
          color: var(--text-secondary);
          padding: 10px 16px;
        }
        
        .btn-ghost:hover {
          color: var(--text-primary);
          background: var(--bg-tertiary);
        }
        
        .btn-icon {
          width: 44px;
          height: 44px;
          padding: 0;
          border-radius: 12px;
        }
        
        .btn:disabled {
          opacity: 0.5;
          cursor: not-allowed;
          transform: none;
        }
        
        /* Dashboard */
        .dashboard {
          min-height: 100vh;
          padding: 24px;
        }
        
        .dashboard-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 32px;
          padding-bottom: 24px;
          border-bottom: 1px solid var(--border-color);
        }
        
        .dashboard-brand {
          display: flex;
          align-items: center;
          gap: 16px;
        }
        
        .brand-icon {
          width: 48px;
          height: 48px;
          background: var(--gradient-primary);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
        }
        
        .brand-text h1 {
          font-size: 20px;
          font-weight: 700;
        }
        
        .brand-text span {
          font-size: 13px;
          color: var(--text-secondary);
        }
        
        .header-actions {
          display: flex;
          align-items: center;
          gap: 12px;
        }
        
        .user-badge {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 8px 16px 8px 8px;
          background: var(--bg-tertiary);
          border-radius: 12px;
          border: 1px solid var(--border-color);
        }
        
        .user-avatar {
          width: 36px;
          height: 36px;
          background: var(--accent-secondary);
          border-radius: 8px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-weight: 600;
          font-size: 14px;
        }
        
        .user-info {
          line-height: 1.3;
        }
        
        .user-name {
          font-weight: 600;
          font-size: 14px;
        }
        
        .user-role {
          font-size: 12px;
          color: var(--text-secondary);
        }
        
        /* Stats Grid */
        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
          gap: 20px;
          margin-bottom: 32px;
        }
        
        .stat-card {
          background: var(--bg-secondary);
          border: 1px solid var(--border-color);
          border-radius: 16px;
          padding: 24px;
          position: relative;
          overflow: hidden;
        }
        
        .stat-card::before {
          content: '';
          position: absolute;
          top: 0;
          left: 0;
          right: 0;
          height: 3px;
          background: var(--gradient-primary);
          opacity: 0.5;
        }
        
        .stat-icon {
          width: 48px;
          height: 48px;
          background: var(--bg-tertiary);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
          margin-bottom: 16px;
        }
        
        .stat-value {
          font-size: 32px;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
          margin-bottom: 4px;
        }
        
        .stat-label {
          font-size: 14px;
          color: var(--text-secondary);
        }
        
        /* Quick Actions */
        .quick-actions {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 20px;
          margin-bottom: 32px;
        }
        
        .action-card {
          background: var(--bg-secondary);
          border: 1px solid var(--border-color);
          border-radius: 16px;
          padding: 28px;
          cursor: pointer;
          transition: all 0.3s ease;
          position: relative;
          overflow: hidden;
        }
        
        .action-card:hover {
          transform: translateY(-4px);
          border-color: var(--accent-primary);
          box-shadow: var(--shadow-glow);
        }
        
        .action-card::after {
          content: '→';
          position: absolute;
          right: 24px;
          top: 50%;
          transform: translateY(-50%);
          font-size: 24px;
          color: var(--accent-primary);
          opacity: 0;
          transition: all 0.3s ease;
        }
        
        .action-card:hover::after {
          opacity: 1;
          right: 20px;
        }
        
        .action-icon {
          width: 56px;
          height: 56px;
          border-radius: 14px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 28px;
          margin-bottom: 20px;
        }
        
        .action-icon.sync { background: linear-gradient(135deg, rgba(0, 217, 255, 0.2) 0%, rgba(0, 217, 255, 0.05) 100%); }
        .action-icon.schedule { background: linear-gradient(135deg, rgba(124, 58, 237, 0.2) 0%, rgba(124, 58, 237, 0.05) 100%); }
        .action-icon.scanner { background: linear-gradient(135deg, rgba(16, 185, 129, 0.2) 0%, rgba(16, 185, 129, 0.05) 100%); }
        .action-icon.approval { background: linear-gradient(135deg, rgba(245, 158, 11, 0.2) 0%, rgba(245, 158, 11, 0.05) 100%); }
        
        .action-title {
          font-size: 18px;
          font-weight: 600;
          margin-bottom: 8px;
        }
        
        .action-description {
          font-size: 14px;
          color: var(--text-secondary);
          line-height: 1.5;
        }
        
        /* Panel/Card Base */
        .panel {
          background: var(--bg-secondary);
          border: 1px solid var(--border-color);
          border-radius: 16px;
          overflow: hidden;
        }
        
        .panel-header {
          padding: 20px 24px;
          border-bottom: 1px solid var(--border-color);
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        
        .panel-title {
          font-size: 16px;
          font-weight: 600;
        }
        
        .panel-body {
          padding: 24px;
        }
        
        /* Table Styles */
        .data-table {
          width: 100%;
          border-collapse: collapse;
        }
        
        .data-table th,
        .data-table td {
          padding: 14px 16px;
          text-align: left;
          border-bottom: 1px solid var(--border-color);
        }
        
        .data-table th {
          font-size: 12px;
          font-weight: 600;
          color: var(--text-secondary);
          text-transform: uppercase;
          letter-spacing: 0.5px;
          background: var(--bg-tertiary);
        }
        
        .data-table tr:last-child td {
          border-bottom: none;
        }
        
        .data-table tr:hover td {
          background: var(--bg-tertiary);
        }
        
        /* Status Badges */
        .status-badge {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          padding: 6px 12px;
          border-radius: 20px;
          font-size: 12px;
          font-weight: 600;
        }
        
        .status-badge.active { background: rgba(16, 185, 129, 0.15); color: var(--accent-success); }
        .status-badge.pending { background: rgba(245, 158, 11, 0.15); color: var(--accent-warning); }
        .status-badge.scheduled { background: rgba(0, 217, 255, 0.15); color: var(--accent-primary); }
        .status-badge.completed { background: rgba(124, 58, 237, 0.15); color: var(--accent-secondary); }
        .status-badge.error { background: rgba(239, 68, 68, 0.15); color: var(--accent-error); }
        
        /* Scanning Screen */
        .scan-container {
          padding: 24px;
          min-height: 100vh;
        }
        
        .scan-header {
          display: flex;
          align-items: center;
          gap: 16px;
          margin-bottom: 32px;
        }
        
        .scan-visual {
          background: var(--bg-secondary);
          border: 2px solid var(--border-color);
          border-radius: 24px;
          padding: 48px;
          text-align: center;
          margin-bottom: 32px;
          position: relative;
          overflow: hidden;
        }
        
        .scan-visual.scanning {
          border-color: var(--accent-primary);
          animation: scanPulse 2s ease-in-out infinite;
        }
        
        @keyframes scanPulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(0, 217, 255, 0.4); }
          50% { box-shadow: 0 0 0 20px rgba(0, 217, 255, 0); }
        }
        
        .scan-animation {
          width: 200px;
          height: 200px;
          margin: 0 auto 24px;
          position: relative;
        }
        
        .scan-ring {
          position: absolute;
          inset: 0;
          border: 3px solid var(--accent-primary);
          border-radius: 50%;
          opacity: 0.3;
        }
        
        .scan-ring.animated {
          animation: ringExpand 1.5s ease-out infinite;
        }
        
        @keyframes ringExpand {
          0% { transform: scale(0.8); opacity: 0.8; }
          100% { transform: scale(1.3); opacity: 0; }
        }
        
        .scan-icon {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%);
          font-size: 64px;
        }
        
        .scan-count {
          font-size: 48px;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
          background: var(--gradient-primary);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        
        .scan-label {
          font-size: 16px;
          color: var(--text-secondary);
          margin-top: 8px;
        }
        
        .scan-results {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 20px;
        }
        
        .result-card {
          background: var(--bg-tertiary);
          border-radius: 16px;
          padding: 24px;
          text-align: center;
        }
        
        .result-value {
          font-size: 36px;
          font-weight: 700;
          font-family: 'JetBrains Mono', monospace;
        }
        
        .result-value.success { color: var(--accent-success); }
        .result-value.warning { color: var(--accent-warning); }
        .result-value.info { color: var(--accent-primary); }
        
        .result-label {
          font-size: 14px;
          color: var(--text-secondary);
          margin-top: 8px;
        }
        
        /* Empty State */
        .empty-state {
          text-align: center;
          padding: 60px 20px;
          color: var(--text-secondary);
        }
        
        .empty-icon {
          font-size: 64px;
          margin-bottom: 20px;
          opacity: 0.3;
        }
        
        .empty-title {
          font-size: 18px;
          font-weight: 600;
          color: var(--text-primary);
          margin-bottom: 8px;
        }
        
        .empty-description {
          font-size: 14px;
          max-width: 400px;
          margin: 0 auto;
        }
        
        /* Modal */
        .modal-overlay {
          position: fixed;
          inset: 0;
          background: rgba(0, 0, 0, 0.7);
          backdrop-filter: blur(4px);
          display: flex;
          align-items: center;
          justify-content: center;
          z-index: 100;
          padding: 20px;
        }
        
        .modal {
          background: var(--bg-secondary);
          border: 1px solid var(--border-color);
          border-radius: 20px;
          width: 100%;
          max-width: 560px;
          max-height: 90vh;
          overflow: hidden;
          animation: modalIn 0.3s ease;
        }
        
        @keyframes modalIn {
          from { transform: scale(0.95); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        
        .modal-header {
          padding: 24px;
          border-bottom: 1px solid var(--border-color);
          display: flex;
          align-items: center;
          justify-content: space-between;
        }
        
        .modal-title {
          font-size: 20px;
          font-weight: 600;
        }
        
        .modal-body {
          padding: 24px;
          overflow-y: auto;
          max-height: 60vh;
        }
        
        .modal-footer {
          padding: 20px 24px;
          border-top: 1px solid var(--border-color);
          display: flex;
          justify-content: flex-end;
          gap: 12px;
        }
        
        /* Checkbox/Selection */
        .checkbox-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }
        
        .checkbox-item {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 14px 16px;
          background: var(--bg-tertiary);
          border: 1px solid var(--border-color);
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .checkbox-item:hover {
          border-color: var(--accent-primary);
        }
        
        .checkbox-item.selected {
          border-color: var(--accent-primary);
          background: rgba(0, 217, 255, 0.05);
        }
        
        .checkbox-box {
          width: 22px;
          height: 22px;
          border: 2px solid var(--border-color);
          border-radius: 6px;
          display: flex;
          align-items: center;
          justify-content: center;
          transition: all 0.2s ease;
          flex-shrink: 0;
        }
        
        .checkbox-item.selected .checkbox-box {
          background: var(--accent-primary);
          border-color: var(--accent-primary);
        }
        
        .checkbox-label {
          flex: 1;
        }
        
        .checkbox-sublabel {
          font-size: 12px;
          color: var(--text-secondary);
          margin-top: 2px;
        }
        
        /* Progress */
        .progress-bar {
          height: 8px;
          background: var(--bg-tertiary);
          border-radius: 4px;
          overflow: hidden;
        }
        
        .progress-fill {
          height: 100%;
          background: var(--gradient-primary);
          border-radius: 4px;
          transition: width 0.3s ease;
        }
        
        /* Device Cards */
        .device-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
          gap: 16px;
        }
        
        .device-card {
          background: var(--bg-tertiary);
          border: 1px solid var(--border-color);
          border-radius: 16px;
          padding: 20px;
          cursor: pointer;
          transition: all 0.2s ease;
        }
        
        .device-card:hover {
          border-color: var(--accent-primary);
        }
        
        .device-card.connected {
          border-color: var(--accent-success);
          background: rgba(16, 185, 129, 0.05);
        }
        
        .device-header {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 16px;
        }
        
        .device-icon {
          width: 48px;
          height: 48px;
          background: var(--bg-elevated);
          border-radius: 12px;
          display: flex;
          align-items: center;
          justify-content: center;
          font-size: 24px;
        }
        
        .device-icon.rf { color: var(--accent-primary); }
        .device-icon.rfid { color: var(--accent-secondary); }
        
        .device-name {
          font-weight: 600;
          margin-bottom: 2px;
        }
        
        .device-type {
          font-size: 12px;
          color: var(--text-secondary);
        }
        
        .device-status {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 13px;
          color: var(--text-secondary);
        }
        
        .status-dot {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: var(--accent-success);
        }
        
        /* Utility Classes */
        .flex { display: flex; }
        .flex-col { flex-direction: column; }
        .items-center { align-items: center; }
        .justify-between { justify-content: space-between; }
        .gap-2 { gap: 8px; }
        .gap-3 { gap: 12px; }
        .gap-4 { gap: 16px; }
        .mt-4 { margin-top: 16px; }
        .mt-6 { margin-top: 24px; }
        .mb-4 { margin-bottom: 16px; }
        .mb-6 { margin-bottom: 24px; }
        .text-center { text-align: center; }
        .text-muted { color: var(--text-secondary); }
        .font-mono { font-family: 'JetBrains Mono', monospace; }
      `}</style>
      
      {/* Notifications */}
      <div className="notifications">
        {notifications.map(n => (
          <div key={n.id} className={`notification ${n.type}`}>
            <span>{n.type === 'success' ? '✓' : n.type === 'error' ? '✕' : n.type === 'warning' ? '⚠' : 'ℹ'}</span>
            <span>{n.message}</span>
          </div>
        ))}
      </div>
      
      {renderView()}
    </div>
  );
}

// ============================================================================
// LOGIN SCREEN COMPONENT
// ============================================================================

function LoginScreen({ onLogin }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await onLogin({ email, password });
    setLoading(false);
  };

  return (
    <div className="login-container">
      <div className="login-background" />
      <div className="login-card">
        <div className="login-logo">
          <div className="login-logo-icon">📡</div>
          <h1>AssetTrack Pro</h1>
          <p>RF & RFID Asset Management</p>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">NetSuite Email</label>
            <input
              type="email"
              className="form-input"
              placeholder="you@company.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              required
            />
          </div>
          
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
              required
            />
          </div>
          
          <button type="submit" className="btn btn-primary" disabled={loading}>
            {loading ? (
              <>
                <span>Authenticating</span>
                <span>...</span>
              </>
            ) : (
              <>
                <span>Sign In to NetSuite</span>
                <span>→</span>
              </>
            )}
          </button>
        </form>
        
        <p style={{ textAlign: 'center', marginTop: '24px', fontSize: '13px', color: 'var(--text-muted)' }}>
          Secured with NetSuite OAuth 2.0
        </p>
      </div>
    </div>
  );
}

// ============================================================================
// DASHBOARD COMPONENT
// ============================================================================

function Dashboard({ user, assets, areas, schedules, syncStatus, onSync, onNavigate, pendingApprovals }) {
  const scheduledCounts = schedules.filter(s => s.status === 'Scheduled').length;
  const recentScans = assets.filter(a => {
    const lastScan = new Date(a.lastScanned);
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    return lastScan > weekAgo;
  }).length;

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div className="dashboard-brand">
          <div className="brand-icon">📡</div>
          <div className="brand-text">
            <h1>AssetTrack Pro</h1>
            <span>NetSuite Integration Active</span>
          </div>
        </div>
        
        <div className="header-actions">
          <button className="btn btn-secondary" onClick={onSync} disabled={syncStatus.syncing}>
            {syncStatus.syncing ? '⟳ Syncing...' : '⟳ Sync NetSuite'}
          </button>
          
          <div className="user-badge">
            <div className="user-avatar">
              {user?.name?.split(' ').map(n => n[0]).join('')}
            </div>
            <div className="user-info">
              <div className="user-name">{user?.name}</div>
              <div className="user-role">{user?.role}</div>
            </div>
          </div>
        </div>
      </header>
      
      {/* Stats */}
      <div className="stats-grid">
        <div className="stat-card">
          <div className="stat-icon">📦</div>
          <div className="stat-value">{assets.length.toLocaleString()}</div>
          <div className="stat-label">Total Assets</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📍</div>
          <div className="stat-value">{areas.length}</div>
          <div className="stat-label">Tracking Areas</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">📅</div>
          <div className="stat-value">{scheduledCounts}</div>
          <div className="stat-label">Scheduled Counts</div>
        </div>
        <div className="stat-card">
          <div className="stat-icon">✓</div>
          <div className="stat-value">{recentScans}</div>
          <div className="stat-label">Scanned This Week</div>
        </div>
      </div>
      
      {/* Quick Actions */}
      <div className="quick-actions">
        <div className="action-card" onClick={() => onNavigate('sync')}>
          <div className="action-icon sync">🔄</div>
          <div className="action-title">Sync Assets</div>
          <div className="action-description">
            Pull latest asset data from NetSuite including locations and tags
          </div>
        </div>
        
        <div className="action-card" onClick={() => onNavigate('scheduling')}>
          <div className="action-icon schedule">📅</div>
          <div className="action-title">Schedule Count</div>
          <div className="action-description">
            Create and manage asset count schedules by area
          </div>
        </div>
        
        <div className="action-card" onClick={() => onNavigate('scanners')}>
          <div className="action-icon scanner">📱</div>
          <div className="action-title">Scanner Setup</div>
          <div className="action-description">
            Connect RF barcode and RFID scanners for asset capture
          </div>
        </div>
        
        <div className="action-card" onClick={() => onNavigate('approvals')}>
          <div className="action-icon approval">✅</div>
          <div className="action-title">Approvals</div>
          <div className="action-description">
            Review and approve scan results for NetSuite sync
            {pendingApprovals.length > 0 && (
              <span className="status-badge pending" style={{ marginLeft: '8px' }}>
                {pendingApprovals.length} pending
              </span>
            )}
          </div>
        </div>
      </div>
      
      {/* Recent Activity */}
      {syncStatus.lastSync && (
        <div className="panel">
          <div className="panel-header">
            <span className="panel-title">Sync Status</span>
            <span className="status-badge active">Connected</span>
          </div>
          <div className="panel-body">
            <p className="text-muted">
              Last synchronized: {new Date(syncStatus.lastSync).toLocaleString()}
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// SYNC SCREEN COMPONENT
// ============================================================================

function SyncScreen({ syncStatus, onSync, assets, areas, onBack }) {
  return (
    <div className="dashboard">
      <div className="scan-header">
        <button className="btn btn-ghost" onClick={onBack}>← Back</button>
        <h2>NetSuite Sync</h2>
      </div>
      
      <div className="panel mb-6">
        <div className="panel-header">
          <span className="panel-title">Sync Status</span>
          {syncStatus.syncing ? (
            <span className="status-badge pending">Syncing...</span>
          ) : (
            <span className="status-badge active">Ready</span>
          )}
        </div>
        <div className="panel-body">
          <div className="stats-grid" style={{ marginBottom: '24px' }}>
            <div className="stat-card">
              <div className="stat-value">{assets.length}</div>
              <div className="stat-label">Assets Synced</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{areas.length}</div>
              <div className="stat-label">Areas Loaded</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{assets.filter(a => a.rfidTag).length}</div>
              <div className="stat-label">RFID Tags</div>
            </div>
          </div>
          
          {syncStatus.lastSync && (
            <p className="text-muted mb-4">
              Last sync: {new Date(syncStatus.lastSync).toLocaleString()}
            </p>
          )}
          
          <button 
            className="btn btn-primary" 
            onClick={onSync}
            disabled={syncStatus.syncing}
            style={{ width: 'auto' }}
          >
            {syncStatus.syncing ? '⟳ Syncing...' : '⟳ Sync Now'}
          </button>
        </div>
      </div>
      
      {areas.length > 0 && (
        <div className="panel">
          <div className="panel-header">
            <span className="panel-title">Synced Areas</span>
          </div>
          <div className="panel-body" style={{ padding: 0 }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Area ID</th>
                  <th>Name</th>
                  <th>Asset Count</th>
                </tr>
              </thead>
              <tbody>
                {areas.map(area => (
                  <tr key={area.id}>
                    <td className="font-mono">{area.id}</td>
                    <td>{area.name}</td>
                    <td>{area.assetCount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// SCHEDULING SCREEN COMPONENT
// ============================================================================

function SchedulingScreen({ areas, schedules, onCreateSchedule, onStartScan, onBack }) {
  const [showModal, setShowModal] = useState(false);
  const [selectedAreas, setSelectedAreas] = useState([]);
  const [scheduleDate, setScheduleDate] = useState('');
  const [scheduleName, setScheduleName] = useState('');

  const toggleArea = (areaId) => {
    setSelectedAreas(prev => 
      prev.includes(areaId) 
        ? prev.filter(id => id !== areaId)
        : [...prev, areaId]
    );
  };

  const handleCreate = () => {
    if (selectedAreas.length > 0 && scheduleDate && scheduleName) {
      onCreateSchedule({
        name: scheduleName,
        areas: selectedAreas,
        scheduledDate: scheduleDate,
        type: 'Full Count'
      });
      setShowModal(false);
      setSelectedAreas([]);
      setScheduleDate('');
      setScheduleName('');
    }
  };

  return (
    <div className="dashboard">
      <div className="scan-header">
        <button className="btn btn-ghost" onClick={onBack}>← Back</button>
        <h2>Asset Count Scheduling</h2>
      </div>
      
      <div className="flex justify-between items-center mb-6">
        <p className="text-muted">Create and manage scheduled asset counts by area</p>
        <button className="btn btn-primary" onClick={() => setShowModal(true)} style={{ width: 'auto' }}>
          + New Schedule
        </button>
      </div>
      
      {schedules.length === 0 ? (
        <div className="panel">
          <div className="empty-state">
            <div className="empty-icon">📅</div>
            <div className="empty-title">No Schedules Yet</div>
            <div className="empty-description">
              Create your first asset count schedule to start tracking inventory
            </div>
          </div>
        </div>
      ) : (
        <div className="panel">
          <div className="panel-body" style={{ padding: 0 }}>
            <table className="data-table">
              <thead>
                <tr>
                  <th>Schedule</th>
                  <th>Areas</th>
                  <th>Date</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {schedules.map(schedule => (
                  <tr key={schedule.id}>
                    <td>
                      <strong>{schedule.name}</strong>
                      <div className="text-muted" style={{ fontSize: '12px' }}>{schedule.id}</div>
                    </td>
                    <td>{schedule.areas.length} area(s)</td>
                    <td>{new Date(schedule.scheduledDate).toLocaleDateString()}</td>
                    <td>
                      <span className={`status-badge ${schedule.status.toLowerCase()}`}>
                        {schedule.status}
                      </span>
                    </td>
                    <td>
                      <button 
                        className="btn btn-secondary" 
                        style={{ padding: '8px 16px', fontSize: '13px' }}
                        onClick={() => onStartScan(schedule)}
                      >
                        Start Scan
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Create Schedule Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={() => setShowModal(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-header">
              <span className="modal-title">New Asset Count Schedule</span>
              <button className="btn btn-ghost btn-icon" onClick={() => setShowModal(false)}>✕</button>
            </div>
            <div className="modal-body">
              <div className="form-group">
                <label className="form-label">Schedule Name</label>
                <input
                  type="text"
                  className="form-input"
                  placeholder="Q1 Warehouse Audit"
                  value={scheduleName}
                  onChange={e => setScheduleName(e.target.value)}
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Scheduled Date</label>
                <input
                  type="date"
                  className="form-input"
                  value={scheduleDate}
                  onChange={e => setScheduleDate(e.target.value)}
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Select Areas ({selectedAreas.length} selected)</label>
                <div className="checkbox-list">
                  {areas.map(area => (
                    <div 
                      key={area.id}
                      className={`checkbox-item ${selectedAreas.includes(area.id) ? 'selected' : ''}`}
                      onClick={() => toggleArea(area.id)}
                    >
                      <div className="checkbox-box">
                        {selectedAreas.includes(area.id) && '✓'}
                      </div>
                      <div className="checkbox-label">
                        <div>{area.name}</div>
                        <div className="checkbox-sublabel">{area.assetCount} assets</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="modal-footer">
              <button className="btn btn-secondary" onClick={() => setShowModal(false)}>Cancel</button>
              <button 
                className="btn btn-primary" 
                onClick={handleCreate}
                disabled={!scheduleName || !scheduleDate || selectedAreas.length === 0}
                style={{ width: 'auto' }}
              >
                Create Schedule
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ============================================================================
// SCANNER SETUP SCREEN COMPONENT
// ============================================================================

function ScannerSetupScreen({ scanners, connectedScanner, onDiscover, onConnect, onBack }) {
  return (
    <div className="dashboard">
      <div className="scan-header">
        <button className="btn btn-ghost" onClick={onBack}>← Back</button>
        <h2>Scanner Setup</h2>
      </div>
      
      <div className="flex justify-between items-center mb-6">
        <p className="text-muted">Connect RF barcode and RFID scanners</p>
        <button className="btn btn-primary" onClick={onDiscover} style={{ width: 'auto' }}>
          🔍 Discover Devices
        </button>
      </div>
      
      {connectedScanner && (
        <div className="panel mb-6">
          <div className="panel-header">
            <span className="panel-title">Connected Scanner</span>
            <span className="status-badge active">Active</span>
          </div>
          <div className="panel-body">
            <div className="device-card connected" style={{ cursor: 'default' }}>
              <div className="device-header">
                <div className={`device-icon ${connectedScanner.type.toLowerCase()}`}>
                  {connectedScanner.type === 'RF' ? '📱' : '📡'}
                </div>
                <div>
                  <div className="device-name">{connectedScanner.name}</div>
                  <div className="device-type">{connectedScanner.type} Scanner</div>
                </div>
              </div>
              <div className="device-status">
                <span className="status-dot" />
                <span>Connected and ready</span>
              </div>
            </div>
          </div>
        </div>
      )}
      
      {scanners.length === 0 ? (
        <div className="panel">
          <div className="empty-state">
            <div className="empty-icon">📱</div>
            <div className="empty-title">No Scanners Found</div>
            <div className="empty-description">
              Click "Discover Devices" to search for available RF and RFID scanners
            </div>
          </div>
        </div>
      ) : (
        <div className="panel">
          <div className="panel-header">
            <span className="panel-title">Available Devices</span>
            <span className="text-muted">{scanners.length} found</span>
          </div>
          <div className="panel-body">
            <div className="device-grid">
              {scanners.map(device => (
                <div 
                  key={device.id}
                  className={`device-card ${connectedScanner?.id === device.id ? 'connected' : ''}`}
                  onClick={() => onConnect(device)}
                >
                  <div className="device-header">
                    <div className={`device-icon ${device.type.toLowerCase()}`}>
                      {device.type === 'RF' ? '📱' : '📡'}
                    </div>
                    <div>
                      <div className="device-name">{device.name}</div>
                      <div className="device-type">{device.type} Scanner</div>
                    </div>
                  </div>
                  <div className="device-status">
                    <span className="status-dot" />
                    <span>
                      {device.battery ? `Battery: ${device.battery}%` : `Signal: ${device.signalStrength}`}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
      
      <div className="panel mt-6">
        <div className="panel-header">
          <span className="panel-title">Supported Hardware</span>
        </div>
        <div className="panel-body">
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px' }}>
            <div>
              <strong style={{ display: 'block', marginBottom: '8px' }}>RF Barcode Scanners</strong>
              <ul className="text-muted" style={{ marginLeft: '20px', lineHeight: '1.8' }}>
                <li>Zebra MC9300 Series</li>
                <li>Zebra TC52/TC57</li>
                <li>Honeywell CT60</li>
                <li>Honeywell CK65</li>
                <li>Datalogic Memor Series</li>
              </ul>
            </div>
            <div>
              <strong style={{ display: 'block', marginBottom: '8px' }}>RFID Readers</strong>
              <ul className="text-muted" style={{ marginLeft: '20px', lineHeight: '1.8' }}>
                <li>Impinj R700 Series</li>
                <li>Zebra FX9600</li>
                <li>Zebra RFD40/RFD90</li>
                <li>Honeywell IH25</li>
                <li>ThingMagic M6e</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============================================================================
// SCANNING SCREEN COMPONENT
// ============================================================================

function ScanningScreen({ session, scanner, onProcessResults, onSubmit, onBack }) {
  const [scanning, setScanning] = useState(false);
  const [progress, setProgress] = useState(0);

  const startScan = () => {
    setScanning(true);
    setProgress(0);
    
    // Simulate scanning progress
    const interval = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setScanning(false);
          // Process results
          const results = ScannerService.simulateScan(
            scanner?.type || 'RF',
            session.expectedAssets
          );
          onProcessResults(results);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 300);
  };

  return (
    <div className="scan-container">
      <div className="scan-header">
        <button className="btn btn-ghost" onClick={onBack}>← Back</button>
        <h2>Asset Scanning</h2>
        {scanner && (
          <span className="status-badge active" style={{ marginLeft: 'auto' }}>
            {scanner.name} Connected
          </span>
        )}
      </div>
      
      {session?.status === 'in-progress' && (
        <>
          <div className={`scan-visual ${scanning ? 'scanning' : ''}`}>
            <div className="scan-animation">
              <div className={`scan-ring ${scanning ? 'animated' : ''}`} />
              <div className={`scan-ring ${scanning ? 'animated' : ''}`} style={{ animationDelay: '0.5s' }} />
              <div className="scan-icon">{scanner?.type === 'RFID' ? '📡' : '📱'}</div>
            </div>
            
            {scanning ? (
              <>
                <div className="scan-count">{Math.floor(session.expectedAssets.length * (progress / 100))}</div>
                <div className="scan-label">Assets Scanned</div>
                <div className="progress-bar mt-4" style={{ maxWidth: '300px', margin: '16px auto 0' }}>
                  <div className="progress-fill" style={{ width: `${progress}%` }} />
                </div>
              </>
            ) : (
              <>
                <div className="scan-count">{session.expectedAssets.length}</div>
                <div className="scan-label">Expected Assets in Selected Areas</div>
              </>
            )}
          </div>
          
          {!scanning && (
            <div className="text-center">
              <button className="btn btn-primary" onClick={startScan} style={{ width: 'auto' }}>
                🔊 Start {scanner?.type || 'RF'} Scan
              </button>
            </div>
          )}
        </>
      )}
      
      {session?.status === 'review' && (
        <>
          <div className="scan-results mb-6">
            <div className="result-card">
              <div className="result-value success">{session.scannedAssets.length}</div>
              <div className="result-label">Assets Found</div>
            </div>
            <div className="result-card">
              <div className="result-value warning">{session.missingAssets.length}</div>
              <div className="result-label">Missing</div>
            </div>
            <div className="result-card">
              <div className="result-value info">{session.unexpectedAssets.length}</div>
              <div className="result-label">Unexpected</div>
            </div>
          </div>
          
          <div className="panel mb-6">
            <div className="panel-header">
              <span className="panel-title">Missing Assets</span>
              <span className="status-badge warning">{session.missingAssets.length}</span>
            </div>
            <div className="panel-body" style={{ padding: session.missingAssets.length ? 0 : '24px' }}>
              {session.missingAssets.length === 0 ? (
                <p className="text-muted text-center">All expected assets were found!</p>
              ) : (
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Asset ID</th>
                      <th>Name</th>
                      <th>RF Tag</th>
                      <th>Last Seen</th>
                    </tr>
                  </thead>
                  <tbody>
                    {session.missingAssets.slice(0, 10).map(asset => (
                      <tr key={asset.id}>
                        <td className="font-mono">{asset.id}</td>
                        <td>{asset.name}</td>
                        <td className="font-mono">{asset.rfTag}</td>
                        <td>{new Date(asset.lastScanned).toLocaleDateString()}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
          
          {session.unexpectedAssets.length > 0 && (
            <div className="panel mb-6">
              <div className="panel-header">
                <span className="panel-title">Unexpected Assets</span>
                <span className="status-badge scheduled">{session.unexpectedAssets.length}</span>
              </div>
              <div className="panel-body" style={{ padding: 0 }}>
                <table className="data-table">
                  <thead>
                    <tr>
                      <th>Tag</th>
                      <th>Description</th>
                      <th>Type</th>
                    </tr>
                  </thead>
                  <tbody>
                    {session.unexpectedAssets.map(asset => (
                      <tr key={asset.id}>
                        <td className="font-mono">{asset.tag}</td>
                        <td>{asset.name}</td>
                        <td><span className="status-badge scheduled">{asset.type}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
          
          <div className="flex gap-4 justify-between">
            <button className="btn btn-secondary" onClick={onBack}>
              Cancel
            </button>
            <button className="btn btn-primary" onClick={onSubmit} style={{ width: 'auto' }}>
              Submit for Approval →
            </button>
          </div>
        </>
      )}
    </div>
  );
}

// ============================================================================
// APPROVAL SCREEN COMPONENT
// ============================================================================

function ApprovalScreen({ approvals, onApprove, onReject, onBack }) {
  const [processing, setProcessing] = useState(null);

  const handleApprove = async (id) => {
    setProcessing(id);
    await onApprove(id);
    setProcessing(null);
  };

  return (
    <div className="dashboard">
      <div className="scan-header">
        <button className="btn btn-ghost" onClick={onBack}>← Back</button>
        <h2>Pending Approvals</h2>
      </div>
      
      {approvals.length === 0 ? (
        <div className="panel">
          <div className="empty-state">
            <div className="empty-icon">✅</div>
            <div className="empty-title">No Pending Approvals</div>
            <div className="empty-description">
              Complete asset scans to generate approval requests
            </div>
          </div>
        </div>
      ) : (
        approvals.map(approval => (
          <div key={approval.id} className="panel mb-6">
            <div className="panel-header">
              <div>
                <span className="panel-title">Scan Results - {approval.id}</span>
                <div className="text-muted" style={{ fontSize: '12px', marginTop: '4px' }}>
                  Submitted by {approval.submittedBy} on {new Date(approval.submittedAt).toLocaleString()}
                </div>
              </div>
              <span className="status-badge pending">Pending Review</span>
            </div>
            <div className="panel-body">
              <div className="scan-results mb-6">
                <div className="result-card">
                  <div className="result-value success">
                    {approval.sessionData.scannedAssets.length}
                  </div>
                  <div className="result-label">Found</div>
                </div>
                <div className="result-card">
                  <div className="result-value warning">
                    {approval.sessionData.missingAssets.length}
                  </div>
                  <div className="result-label">Missing</div>
                </div>
                <div className="result-card">
                  <div className="result-value info">
                    {approval.sessionData.unexpectedAssets.length}
                  </div>
                  <div className="result-label">Unexpected</div>
                </div>
              </div>
              
              <div className="flex gap-4 justify-between">
                <button 
                  className="btn btn-secondary" 
                  onClick={() => onReject(approval.id)}
                >
                  Reject
                </button>
                <button 
                  className="btn btn-primary" 
                  onClick={() => handleApprove(approval.id)}
                  disabled={processing === approval.id}
                  style={{ width: 'auto' }}
                >
                  {processing === approval.id ? 'Syncing to NetSuite...' : 'Approve & Sync to NetSuite'}
                </button>
              </div>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
