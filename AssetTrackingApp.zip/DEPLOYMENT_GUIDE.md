# Asset Tracking App - Hosting & Deployment Guide

This guide covers multiple options for hosting the RF/RFID Asset Tracking application, from quick local testing to production deployment.

---

## Option 1: Quick Local Testing (5 minutes)

### Using Vite (Recommended for Development)

```bash
# 1. Create a new Vite project
npm create vite@latest asset-tracking-app -- --template react

# 2. Navigate to the project
cd asset-tracking-app

# 3. Replace src/App.jsx with the provided AssetTrackingApp.jsx
# Copy the contents of AssetTrackingApp.jsx into src/App.jsx

# 4. Install dependencies
npm install

# 5. Start the development server
npm run dev

# App will be available at http://localhost:5173
```

### Using Create React App

```bash
# 1. Create a new React app
npx create-react-app asset-tracking-app

# 2. Navigate to the project
cd asset-tracking-app

# 3. Replace src/App.js with the provided AssetTrackingApp.jsx
# Rename it to App.js and copy the contents

# 4. Start the development server
npm start

# App will be available at http://localhost:3000
```

---

## Option 2: Static Hosting (Free Tier Available)

### Vercel (Easiest - Recommended)

```bash
# 1. Install Vercel CLI
npm install -g vercel

# 2. Create your Vite project (see Option 1)
npm create vite@latest asset-tracking-app -- --template react
cd asset-tracking-app

# 3. Build the project
npm run build

# 4. Deploy to Vercel
vercel

# Follow the prompts - you'll get a live URL like:
# https://asset-tracking-app.vercel.app
```

**Or deploy via GitHub:**
1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click "Import Project" → Select your repo
4. Vercel auto-detects Vite/React and deploys

### Netlify

```bash
# 1. Install Netlify CLI
npm install -g netlify-cli

# 2. Build your project
npm run build

# 3. Deploy to Netlify
netlify deploy --prod --dir=dist

# Or drag-and-drop the 'dist' folder at netlify.com/drop
```

### GitHub Pages (Free)

```bash
# 1. Install gh-pages package
npm install gh-pages --save-dev

# 2. Add to package.json:
{
  "homepage": "https://yourusername.github.io/asset-tracking-app",
  "scripts": {
    "predeploy": "npm run build",
    "deploy": "gh-pages -d dist"
  }
}

# 3. For Vite, update vite.config.js:
export default defineConfig({
  base: '/asset-tracking-app/',
  plugins: [react()]
})

# 4. Deploy
npm run deploy
```

---

## Option 3: Cloud Platform Deployment (Production)

### AWS Amplify

```bash
# 1. Install Amplify CLI
npm install -g @aws-amplify/cli

# 2. Configure Amplify
amplify configure

# 3. Initialize in your project
amplify init

# 4. Add hosting
amplify add hosting
# Select: Hosting with Amplify Console
# Select: Continuous deployment

# 5. Publish
amplify publish
```

### Google Cloud Run (Containerized)

```dockerfile
# Dockerfile
FROM node:18-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf
EXPOSE 8080
CMD ["nginx", "-g", "daemon off;"]
```

```bash
# Build and deploy
gcloud builds submit --tag gcr.io/PROJECT_ID/asset-tracking
gcloud run deploy asset-tracking --image gcr.io/PROJECT_ID/asset-tracking --platform managed
```

### Azure Static Web Apps

```bash
# 1. Install Azure CLI
# 2. Login
az login

# 3. Create Static Web App
az staticwebapp create \
  --name asset-tracking-app \
  --resource-group myResourceGroup \
  --source https://github.com/user/repo \
  --branch main \
  --app-location "/" \
  --output-location "dist"
```

---

## Option 4: Self-Hosted / On-Premises

### Docker Deployment

```dockerfile
# Dockerfile
FROM node:18-alpine AS build
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html

# Custom nginx config for SPA routing
RUN echo 'server { \
    listen 80; \
    location / { \
        root /usr/share/nginx/html; \
        index index.html; \
        try_files $uri $uri/ /index.html; \
    } \
}' > /etc/nginx/conf.d/default.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

```bash
# Build the image
docker build -t asset-tracking-app .

# Run locally
docker run -p 8080:80 asset-tracking-app

# Access at http://localhost:8080
```

### Docker Compose (with Backend)

```yaml
# docker-compose.yml
version: '3.8'

services:
  frontend:
    build: ./frontend
    ports:
      - "80:80"
    depends_on:
      - api

  api:
    build: ./backend
    ports:
      - "3001:3001"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/assets
      - NETSUITE_ACCOUNT_ID=${NETSUITE_ACCOUNT_ID}
      - NETSUITE_CONSUMER_KEY=${NETSUITE_CONSUMER_KEY}
      - NETSUITE_CONSUMER_SECRET=${NETSUITE_CONSUMER_SECRET}
    depends_on:
      - db
      - redis

  db:
    image: postgres:15-alpine
    volumes:
      - postgres_data:/var/lib/postgresql/data
    environment:
      - POSTGRES_DB=assets
      - POSTGRES_USER=user
      - POSTGRES_PASSWORD=pass

  redis:
    image: redis:alpine
    volumes:
      - redis_data:/data

volumes:
  postgres_data:
  redis_data:
```

```bash
# Start all services
docker-compose up -d
```

### Kubernetes Deployment

```yaml
# k8s/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: asset-tracking-frontend
spec:
  replicas: 3
  selector:
    matchLabels:
      app: asset-tracking-frontend
  template:
    metadata:
      labels:
        app: asset-tracking-frontend
    spec:
      containers:
      - name: frontend
        image: your-registry/asset-tracking-app:latest
        ports:
        - containerPort: 80
        resources:
          limits:
            memory: "256Mi"
            cpu: "500m"
---
apiVersion: v1
kind: Service
metadata:
  name: asset-tracking-service
spec:
  selector:
    app: asset-tracking-frontend
  ports:
  - port: 80
    targetPort: 80
  type: LoadBalancer
```

```bash
# Deploy to Kubernetes
kubectl apply -f k8s/deployment.yaml
```

---

## Option 5: Enterprise / Internal Network

### IIS (Windows Server)

1. Build the React app: `npm run build`
2. Copy `dist` folder contents to `C:\inetpub\wwwroot\AssetTracking`
3. In IIS Manager:
   - Create new website pointing to that folder
   - Install URL Rewrite module
   - Add web.config for SPA routing:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
  <system.webServer>
    <rewrite>
      <rules>
        <rule name="SPA Routes" stopProcessing="true">
          <match url=".*" />
          <conditions logicalGrouping="MatchAll">
            <add input="{REQUEST_FILENAME}" matchType="IsFile" negate="true" />
            <add input="{REQUEST_FILENAME}" matchType="IsDirectory" negate="true" />
          </conditions>
          <action type="Rewrite" url="/index.html" />
        </rule>
      </rules>
    </rewrite>
  </system.webServer>
</configuration>
```

### Apache (Linux)

```apache
# /etc/apache2/sites-available/asset-tracking.conf
<VirtualHost *:80>
    ServerName assets.yourcompany.com
    DocumentRoot /var/www/asset-tracking

    <Directory /var/www/asset-tracking>
        Options -Indexes +FollowSymLinks
        AllowOverride All
        Require all granted
    </Directory>

    # SPA fallback
    FallbackResource /index.html

    ErrorLog ${APACHE_LOG_DIR}/asset-tracking-error.log
    CustomLog ${APACHE_LOG_DIR}/asset-tracking-access.log combined
</VirtualHost>
```

```bash
# Enable site and restart
sudo a2ensite asset-tracking.conf
sudo systemctl restart apache2
```

---

## Environment Configuration

### Required Environment Variables

Create a `.env` file for production:

```env
# NetSuite Configuration
VITE_NETSUITE_ACCOUNT_ID=your_account_id
VITE_NETSUITE_REST_URL=https://ACCOUNT_ID.suitetalk.api.netsuite.com
VITE_NETSUITE_CLIENT_ID=your_oauth_client_id

# API Configuration
VITE_API_BASE_URL=https://api.yourcompany.com

# Feature Flags
VITE_ENABLE_RFID=true
VITE_ENABLE_OFFLINE_MODE=true
```

### SSL/HTTPS Configuration

For production, always use HTTPS. Use Let's Encrypt for free certificates:

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Get certificate
sudo certbot --nginx -d assets.yourcompany.com

# Auto-renewal is configured automatically
```

---

## Recommended Production Setup

For a production asset tracking system, we recommend:

| Component | Recommendation |
|-----------|----------------|
| **Frontend Hosting** | Vercel, AWS CloudFront + S3, or Nginx |
| **API Backend** | Node.js on AWS ECS/Lambda or Cloud Run |
| **Database** | AWS RDS PostgreSQL or Cloud SQL |
| **Cache** | AWS ElastiCache Redis |
| **File Storage** | AWS S3 for scan logs/exports |
| **CDN** | CloudFront or Cloudflare |
| **Monitoring** | Datadog, New Relic, or CloudWatch |

---

## Quick Start Command Summary

```bash
# Fastest way to get running locally:
npm create vite@latest asset-app -- --template react
cd asset-app
# Copy AssetTrackingApp.jsx contents to src/App.jsx
npm install
npm run dev

# Fastest way to deploy to internet:
npm run build
npx vercel --prod
```

---

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Blank page after deploy | Check `base` in vite.config.js matches your URL path |
| 404 on refresh | Configure SPA fallback (try_files or FallbackResource) |
| CORS errors | Configure API to allow your frontend domain |
| Scanner not connecting | Ensure HTTPS (required for Web Bluetooth/USB APIs) |

---

*For questions or support, refer to the main ARCHITECTURE.md document.*
